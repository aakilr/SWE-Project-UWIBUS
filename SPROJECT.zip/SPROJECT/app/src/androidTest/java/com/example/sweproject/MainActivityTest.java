package com.example.sweproject;

import org.junit.Test;

import static org.junit.Assert.*;

public class MainActivityTest {
    private MainActivity findDrivers = new MainActivity();
@Test
    public void findDrivers_Test() throws Exception{
    assertTrue(findDrivers.findDrivers());

}




}

