package com.example.sweproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Homepage extends AppCompatActivity {
    private Button register,booking;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        register =  (Button) findViewById(R.id.register);
        register.setOnClickListener(new Button_Clicker());

        booking =  (Button) findViewById(R.id.booking);
        booking.setOnClickListener(new Button_Clicker());
    }
    class Button_Clicker implements Button.OnClickListener {

        @Override

        public void onClick(View v) {

            if (v == register) {
                Intent myIntent = new Intent(getApplicationContext(),registration.class);
                startActivity(myIntent);

            }
            if(v==booking){
                Intent myIntent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(myIntent);
            }




        }
    }
}
