package com.example.sweproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Panic extends AppCompatActivity {
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panic);
        button = findViewById(R.id.button3);
        button.setOnClickListener(new Button_Clicker());

    }

    class Button_Clicker implements Button.OnClickListener {

        @Override

        public void onClick(View v) {
        if(v==button){
            EditText edit = findViewById(R.id.editText2);
            edit.setText("HELP IS ON THE WAY");

        }

        }
        }
}
